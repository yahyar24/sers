<div class="panel panel-default">
        <div class="panel panel-heading">
            Users
        </div>
        <div class="panel panel-body">
            <table class="table table-hover">
                <thead>
                <th>
                    الصورة
                </th>
                <th>
                    الاسم
                </th>
                <th>
                    الترخيص
                </th>
                <th>
                    حذف
                </th>
                </thead>

                <tbody>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td>
                            <img src="<?php echo e(asset($user->nofile->avatar)); ?>"  alt="" width="60" height="60" style="border-radius: 50%;">
                        </td>
                        <td>
                            <?php echo e($user->name); ?>

                        </td>
                        <td>
                            <?php if($user->admin): ?>

                                <a href="<?php echo e(route('user.not.admin',['id' => $user->id])); ?>" class="btn-danger btn-xs">انهاء الترخيص</a>

                            <?php else: ?>
                            <a href="<?php echo e(route('user.admin',['id' => $user->id])); ?>" class="btn-success btn-xs">رفع الى ادمن</a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(Auth::id()!== $user->id): ?>

                                <a href="<?php echo e(route('user.delete',['id' =>$user->id])); ?>" class="btn-danger btn-xs">حذف المستخدم</a>

                                <?php endif; ?>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
            </table>

        </div>
    </div>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajaxL\resources\views/admin/users/index.blade.php ENDPATH**/ ?>