<?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="panel panel-default">
    <div class="panel panel-heading">
        انشاء مستخدم جديد
    </div>
    <div class="panel-body">
        <form action="<?php echo e(route('user.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="name">اسم المستخدم</label>
                <input type="text" name="name" class="form-control">
            </div>
            <div class="form-group">
                <label for="name">البريد الالكتروني</label>
                <input type="email" name="email" class="form-control">
            </div>
            <div class="form-group">
                <div class="text-center">
                    <button class="btn btn-success" type="submit">
                        اضافة مستخدم
                    </button>
                </div>
            </div>

        </form>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\ajaxL\resources\views/admin/users/create.blade.php ENDPATH**/ ?>